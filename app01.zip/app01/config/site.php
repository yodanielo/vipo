<?php
$config['sitename']         = 'VIPO';
$config['sitedescription']  = 'VIPO Software de administración hotelera';
$config['author']           = 'Ing. Daniel POmalaza e Ing. Victor Fajardo';
$config['owner']            = 'VIPO';
?>
