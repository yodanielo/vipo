<?php ?>
<div id="wraplogin">
    <div id="floatlogin">
        <div id="cuadrologin">
            <img src="<?= site_url("principal/img/vipo-login-default-logo.png") ?>" id="logologin" alt="Logo Empresa"/>
            <input type="text" class="form-control input-lg" id="txtusername" placeholder="Username" />
            <input type="text" class="form-control input-lg" id="txtpassword" placeholder="Password" />
            <input type="submit" class="btn btn-primary btn-lg" id="btnlogin" placeholder="Password" />
            <a id="lnkforgot" href="#">Forgot your password?</a>
        </div>
    </div>
</div>