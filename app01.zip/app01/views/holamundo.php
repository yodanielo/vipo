<h1>Hola <?php echo $params["nombre"] ?> <?=$params["apellido"]?></h1>
<h2>Hola <?= $params["nombre"]." ".$params["apellido"]?></h2>